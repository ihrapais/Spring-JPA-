package com.example.jpa;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "carrinhos")
public class CarrinhoDeCompras {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "carrinho_produtos", joinColumns = @JoinColumn(name = "carrinho_id"))
    @Column(name = "produto_id")
    private List<Long> produtos; // IDs dos produtos

    @Column(name = "subtotal", nullable = false)
    private Double subtotal;

    // outros campos e métodos omitidos por brevidade
}