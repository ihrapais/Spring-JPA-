package com.example.jpa;

import jakarta.persistence.*;


@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "senha", nullable = false)
    private String senha;

    @Column(name = "papel", nullable = false)
    private String papel; // admin ou staff

    // outros campos e métodos omitidos por brevidade
}