import jakarta.persistence.*;

@Entity
@Table(name = "produtos")
public class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nome", nullable = false)
    private String nome;

    @Column(name = "descricao")
    private String descricao;

    @Column(name = "preco", nullable = false)
    private Double preco;

    @Column(name = "categoria", nullable = false)
    private String categoria;

    @Column(name = "disponivel", nullable = false)
    private Boolean disponivel;

    @Column(name = "imagem_url")
    private String imagemUrl;

    // outros campos e métodos omitidos por brevidade
}