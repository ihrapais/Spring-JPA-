package com.example.jpa;

import jakarta.persistence.*;

@Entity
@Table(name = "pagamentos")
public class Pagamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pedido_id", nullable = false)
    private Pedido pedido;

    @Column(name = "metodo_pagamento", nullable = false)
    private String metodoPagamento; // ex: cartão de crédito, débito, dinheiro

    @Column(name = "valor", nullable = false)
    private Double valor;

    @Column(name = "status", nullable = false)
    private String status; // ex: pago, pendente

    @Column(name = "transacao_id")
    private String transacaoId;
}

// outros campos e métodos omitidos por brevidade