package com.example.pratice_1.model;

import jakarta.persistence.*;

@Entity
@Table(name = "localizacao_dep")
public class LocalizacaoDep {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "dnumero")
    private Departamento departamento;

    @Column(name = "dlocal", length = 15)
    private String dlocal;

    public LocalizacaoDep() {}

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public String getDlocal() {
        return dlocal;
    }

    public void setDlocal(String dlocal) {
        this.dlocal = dlocal;
    }
}