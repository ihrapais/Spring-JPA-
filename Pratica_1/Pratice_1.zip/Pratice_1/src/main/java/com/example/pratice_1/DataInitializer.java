package com.example.pratice_1;

import com.example.pratice_1.model.*;
import com.example.pratice_1.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @Autowired
    private DepartamentoRepository departamentoRepository;

    @Autowired
    private ProjetoRepository projetoRepository;

    @Autowired
    private DependenteRepository dependenteRepository;

    @Autowired
    private TrabalhaEmRepository trabalhaEmRepository;

    @Autowired
    private LocalizacaoDepRepository localizacaoDepRepository;

    @Override
    public void run(String... args) throws Exception {
        // Departamentos
        Departamento pesquisa = new Departamento();
        pesquisa.setDnumero(5);
        pesquisa.setDnome("Pesquisa");
        departamentoRepository.save(pesquisa);

        Departamento administracao = new Departamento();
        administracao.setDnumero(4);
        administracao.setDnome("Administração");
        departamentoRepository.save(administracao);

        Departamento matriz = new Departamento();
        matriz.setDnumero(1);
        matriz.setDnome("Matriz");
        departamentoRepository.save(matriz);

        // Funcionários
        Funcionario joao = new Funcionario();
        joao.setCpf("12345678966");
        joao.setPnome("João");
        joao.setMinicial("B");
        joao.setUnome("Silva");
        joao.setDatanasc(LocalDate.of(1965, 1, 9));
        joao.setEndereco("Rua das Flores, 751, São Paulo, SP");
        joao.setSexo("M");
        joao.setSalario(new BigDecimal("30000"));
        joao.setDepartamento(pesquisa);
        funcionarioRepository.save(joao);

        Funcionario fernando = new Funcionario();
        fernando.setCpf("33344555587");
        fernando.setPnome("Fernando");
        fernando.setMinicial("T");
        fernando.setUnome("Wong");
        fernando.setDatanasc(LocalDate.of(1955, 12, 8));
        fernando.setEndereco("Rua da Lapa, 34, São Paulo, SP");
        fernando.setSexo("M");
        fernando.setSalario(new BigDecimal("40000"));
        fernando.setDepartamento(pesquisa);
        funcionarioRepository.save(fernando);

        Funcionario alice = new Funcionario();
        alice.setCpf("99988777767");
        alice.setPnome("Alice");
        alice.setMinicial("J");
        alice.setUnome("Zelaya");
        alice.setDatanasc(LocalDate.of(1968, 1, 19));
        alice.setEndereco("Rua Souza Lima, 35, Curitiba, PR");
        alice.setSexo("F");
        alice.setSalario(new BigDecimal("25000"));
        alice.setDepartamento(administracao);
        funcionarioRepository.save(alice);

        Funcionario jennifer = new Funcionario();
        jennifer.setCpf("98765432168");
        jennifer.setPnome("Jennifer");
        jennifer.setMinicial("S");
        jennifer.setUnome("Souza");
        jennifer.setDatanasc(LocalDate.of(1941, 6, 20));
        jennifer.setEndereco("Av. Arthur de Lima, 54, Santo André, SP");
        jennifer.setSexo("F");
        jennifer.setSalario(new BigDecimal("43000"));
        jennifer.setDepartamento(administracao);
        funcionarioRepository.save(jennifer);

        Funcionario ronaldo = new Funcionario();
        ronaldo.setCpf("66688444476");
        ronaldo.setPnome("Ronaldo");
        ronaldo.setMinicial("K");
        ronaldo.setUnome("Lima");
        ronaldo.setDatanasc(LocalDate.of(1962, 9, 15));
        ronaldo.setEndereco("Rua Rebouças, 65, Piracicaba, SP");
        ronaldo.setSexo("M");
        ronaldo.setSalario(new BigDecimal("38000"));
        ronaldo.setDepartamento(pesquisa);
        funcionarioRepository.save(ronaldo);

        Funcionario joice = new Funcionario();
        joice.setCpf("45345345376");
        joice.setPnome("Joice");
        joice.setMinicial("A");
        joice.setUnome("Leite");
        joice.setDatanasc(LocalDate.of(1972, 7, 31));
        joice.setEndereco("Av. Lucas Obes, 74, São Paulo, SP");
        joice.setSexo("F");
        joice.setSalario(new BigDecimal("25000"));
        joice.setDepartamento(pesquisa);
        funcionarioRepository.save(joice);

        Funcionario andre = new Funcionario();
        andre.setCpf("98798798733");
        andre.setPnome("André");
        andre.setMinicial("V");
        andre.setUnome("Pereira");
        andre.setDatanasc(LocalDate.of(1969, 3, 29));
        andre.setEndereco("Rua Timbira, 35, São Paulo, SP");
        andre.setSexo("M");
        andre.setSalario(new BigDecimal("25000"));
        andre.setDepartamento(administracao);
        funcionarioRepository.save(andre);

        Funcionario jorge = new Funcionario();
        jorge.setCpf("88866555576");
        jorge.setPnome("Jorge");
        jorge.setMinicial("E");
        jorge.setUnome("Brito");
        jorge.setDatanasc(LocalDate.of(1937, 11, 10));
        jorge.setEndereco("Rua do Horto, 35, São Paulo, SP");
        jorge.setSexo("M");
        jorge.setSalario(new BigDecimal("55000"));
        jorge.setDepartamento(matriz);
        funcionarioRepository.save(jorge);

        // Configurar supervisores
        joao.setSupervisor(fernando);
        fernando.setSupervisor(jorge);
        alice.setSupervisor(jennifer);
        jennifer.setSupervisor(jorge);
        ronaldo.setSupervisor(fernando);
        joice.setSupervisor(fernando);
        andre.setSupervisor(jennifer);
        funcionarioRepository.save(joao);
        funcionarioRepository.save(fernando);
        funcionarioRepository.save(alice);
        funcionarioRepository.save(jennifer);
        funcionarioRepository.save(ronaldo);
        funcionarioRepository.save(joice);
        funcionarioRepository.save(andre);

        // Configurar gerentes dos departamentos
        pesquisa.setGerente(fernando);
        pesquisa.setDataInicioGerente(LocalDate.of(1988, 5, 22));
        administracao.setGerente(jennifer);
        administracao.setDataInicioGerente(LocalDate.of(1995, 1, 1));
        matriz.setGerente(jorge);
        matriz.setDataInicioGerente(LocalDate.of(1981, 6, 19));
        departamentoRepository.save(pesquisa);
        departamentoRepository.save(administracao);
        departamentoRepository.save(matriz);

        // Projetos
        Projeto produtoX = new Projeto();
        produtoX.setProjnumero(1);
        produtoX.setProjnome("ProdutoX");
        produtoX.setProjlocal("Santo André");
        produtoX.setDepartamento(matriz);
        projetoRepository.save(produtoX);

        Projeto produtoY = new Projeto();
        produtoY.setProjnumero(2);
        produtoY.setProjnome("ProdutoY");
        produtoY.setProjlocal("Itu");
        produtoY.setDepartamento(pesquisa);
        projetoRepository.save(produtoY);

        Projeto produtoZ = new Projeto();
        produtoZ.setProjnumero(3);
        produtoZ.setProjnome("ProdutoZ");
        produtoZ.setProjlocal("São Paulo");
        produtoZ.setDepartamento(pesquisa);
        projetoRepository.save(produtoZ);

        Projeto informatizacao = new Projeto();
        informatizacao.setProjnumero(10);
        informatizacao.setProjnome("Informatização");
        informatizacao.setProjlocal("Mauá");
        informatizacao.setDepartamento(administracao);
        projetoRepository.save(informatizacao);

        Projeto reorganizacao = new Projeto();
        reorganizacao.setProjnumero(20);
        reorganizacao.setProjnome("Reorganização");
        reorganizacao.setProjlocal("São Paulo");
        reorganizacao.setDepartamento(matriz);
        projetoRepository.save(reorganizacao);

        Projeto novosBeneficios = new Projeto();
        novosBeneficios.setProjnumero(30);
        novosBeneficios.setProjnome("NovosBenefícios");
        novosBeneficios.setProjlocal("Mauá");
        novosBeneficios.setDepartamento(matriz);
        projetoRepository.save(novosBeneficios);

        // TrabalhaEm
        TrabalhaEm t1 = new TrabalhaEm();
        t1.setFuncionario(joao);
        t1.setProjeto(produtoX);
        t1.setHoras(new BigDecimal("32.5"));
        trabalhaEmRepository.save(t1);

        TrabalhaEm t2 = new TrabalhaEm();
        t2.setFuncionario(joao);
        t2.setProjeto(produtoY);
        t2.setHoras(new BigDecimal("7.5"));
        trabalhaEmRepository.save(t2);

        TrabalhaEm t3 = new TrabalhaEm();
        t3.setFuncionario(ronaldo);
        t3.setProjeto(produtoZ);
        t3.setHoras(new BigDecimal("40.0"));
        trabalhaEmRepository.save(t3);

        TrabalhaEm t4 = new TrabalhaEm();
        t4.setFuncionario(joice);
        t4.setProjeto(produtoX);
        t4.setHoras(new BigDecimal("20.0"));
        trabalhaEmRepository.save(t4);

        TrabalhaEm t5 = new TrabalhaEm();
        t5.setFuncionario(joice);
        t5.setProjeto(produtoY);
        t5.setHoras(new BigDecimal("20.0"));
        trabalhaEmRepository.save(t5);

        TrabalhaEm t6 = new TrabalhaEm();
        t6.setFuncionario(fernando);
        t6.setProjeto(produtoY);
        t6.setHoras(new BigDecimal("10.0"));
        trabalhaEmRepository.save(t6);

        TrabalhaEm t7 = new TrabalhaEm();
        t7.setFuncionario(fernando);
        t7.setProjeto(produtoZ);
        t7.setHoras(new BigDecimal("10.0"));
        trabalhaEmRepository.save(t7);

        TrabalhaEm t8 = new TrabalhaEm();
        t8.setFuncionario(fernando);
        t8.setProjeto(novosBeneficios);
        t8.setHoras(new BigDecimal("10.0"));
        trabalhaEmRepository.save(t8);

        TrabalhaEm t9 = new TrabalhaEm();
        t9.setFuncionario(alice);
        t9.setProjeto(informatizacao);
        t9.setHoras(new BigDecimal("10.0"));
        trabalhaEmRepository.save(t9);

        TrabalhaEm t10 = new TrabalhaEm();
        t10.setFuncionario(alice);
        t10.setProjeto(reorganizacao);
        t10.setHoras(new BigDecimal("10.0"));
        trabalhaEmRepository.save(t10);

        TrabalhaEm t11 = new TrabalhaEm();
        t11.setFuncionario(jennifer);
        t11.setProjeto(informatizacao);
        t11.setHoras(new BigDecimal("35.0"));
        trabalhaEmRepository.save(t11);

        TrabalhaEm t12 = new TrabalhaEm();
        t12.setFuncionario(jennifer);
        t12.setProjeto(reorganizacao);
        t12.setHoras(new BigDecimal("5.0"));
        trabalhaEmRepository.save(t12);

        TrabalhaEm t13 = new TrabalhaEm();
        t13.setFuncionario(andre);
        t13.setProjeto(reorganizacao);
        t13.setHoras(new BigDecimal("20.0"));
        trabalhaEmRepository.save(t13);

        TrabalhaEm t14 = new TrabalhaEm();
        t14.setFuncionario(andre);
        t14.setProjeto(novosBeneficios);
        t14.setHoras(new BigDecimal("15.0"));
        trabalhaEmRepository.save(t14);

        // Dependentes
        Dependente d1 = new Dependente();
        d1.setFuncionario(fernando);
        d1.setNomeDependente("Alicia");
        d1.setSexo("F");
        d1.setDatanasc(LocalDate.of(1986, 4, 5));
        d1.setParentesco("Filha");
        dependenteRepository.save(d1);

        Dependente d2 = new Dependente();
        d2.setFuncionario(fernando);
        d2.setNomeDependente("Tiago");
        d2.setSexo("M");
        d2.setDatanasc(LocalDate.of(1983, 10, 25));
        d2.setParentesco("Filho");
        dependenteRepository.save(d2);

        Dependente d3 = new Dependente();
        d3.setFuncionario(fernando);
        d3.setNomeDependente("Janaína");
        d3.setSexo("F");
        d3.setDatanasc(LocalDate.of(1958, 5, 3));
        d3.setParentesco("Esposa");
        dependenteRepository.save(d3);

        Dependente d4 = new Dependente();
        d4.setFuncionario(jennifer);
        d4.setNomeDependente("Antônio");
        d4.setSexo("M");
        d4.setDatanasc(LocalDate.of(1942, 2, 28));
        d4.setParentesco("Marido");
        dependenteRepository.save(d4);

        Dependente d5 = new Dependente();
        d5.setFuncionario(joao);
        d5.setNomeDependente("Michael");
        d5.setSexo("M");
        d5.setDatanasc(LocalDate.of(1988, 1, 4));
        d5.setParentesco("Filho");
        dependenteRepository.save(d5);

        Dependente d6 = new Dependente();
        d6.setFuncionario(joao);
        d6.setNomeDependente("Alicia");
        d6.setSexo("F");
        d6.setDatanasc(LocalDate.of(1988, 12, 30));
        d6.setParentesco("Filha");
        dependenteRepository.save(d6);

        // Localizações
        LocalizacaoDep l1 = new LocalizacaoDep();
        l1.setDepartamento(matriz);
        l1.setDlocal("São Paulo");
        localizacaoDepRepository.save(l1);

        LocalizacaoDep l2 = new LocalizacaoDep();
        l2.setDepartamento(administracao);
        l2.setDlocal("Mauá");
        localizacaoDepRepository.save(l2);

        LocalizacaoDep l3 = new LocalizacaoDep();
        l3.setDepartamento(pesquisa);
        l3.setDlocal("Santo André");
        localizacaoDepRepository.save(l3);

        LocalizacaoDep l4 = new LocalizacaoDep();
        l4.setDepartamento(pesquisa);
        l4.setDlocal("Itu");
        localizacaoDepRepository.save(l4);

        LocalizacaoDep l5 = new LocalizacaoDep();
        l5.setDepartamento(pesquisa);
        l5.setDlocal("São Paulo");
        localizacaoDepRepository.save(l5);
    }
}