package com.example.pratice_1.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "trabalha_em")
public class TrabalhaEm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cpf")
    private Funcionario funcionario;

    @ManyToOne
    @JoinColumn(name = "pnr")
    private Projeto projeto;

    @Column(name = "horas", precision = 3, scale = 1)
    private BigDecimal horas;

    public TrabalhaEm() {}

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public BigDecimal getHoras() {
        return horas;
    }

    public void setHoras(BigDecimal horas) {
        this.horas = horas;
    }
}