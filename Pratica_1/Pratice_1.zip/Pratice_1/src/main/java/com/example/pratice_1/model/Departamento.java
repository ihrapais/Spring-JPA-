package com.example.pratice_1.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "departamento")
public class Departamento {

    @Id
    @Column(name = "dnumero")
    private Integer dnumero;

    @Column(name = "dnome", length = 15)
    private String dnome;

    @OneToOne
    @JoinColumn(name = "cpf_gerente")
    private Funcionario gerente;

    @Column(name = "data_inicio_gerente")
    private LocalDate dataInicioGerente;

    @OneToMany(mappedBy = "departamento")
    private List<Funcionario> funcionarios;

    @OneToMany(mappedBy = "departamento")
    private List<Projeto> projetos;

    @OneToMany(mappedBy = "departamento")
    private List<LocalizacaoDep> localizacoes;

    public Departamento() {}

    // Getters e Setters
    public Integer getDnumero() {
        return dnumero;
    }

    public void setDnumero(Integer dnumero) {
        this.dnumero = dnumero;
    }

    public String getDnome() {
        return dnome;
    }

    public void setDnome(String dnome) {
        this.dnome = dnome;
    }

    public Funcionario getGerente() {
        return gerente;
    }

    public void setGerente(Funcionario gerente) {
        this.gerente = gerente;
    }

    public LocalDate getDataInicioGerente() {
        return dataInicioGerente;
    }

    public void setDataInicioGerente(LocalDate dataInicioGerente) {
        this.dataInicioGerente = dataInicioGerente;
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public List<Projeto> getProjetos() {
        return projetos;
    }

    public void setProjetos(List<Projeto> projetos) {
        this.projetos = projetos;
    }

    public List<LocalizacaoDep> getLocalizacoes() {
        return localizacoes;
    }

    public void setLocalizacoes(List<LocalizacaoDep> localizacoes) {
        this.localizacoes = localizacoes;
    }
}