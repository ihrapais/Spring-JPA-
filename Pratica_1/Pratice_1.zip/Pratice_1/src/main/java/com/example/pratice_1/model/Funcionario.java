package com.example.pratice_1.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "funcionario")
public class Funcionario {

    @Id
    @Column(name = "cpf", length = 11)
    private String cpf;

    @Column(name = "pnome", length = 15)
    private String pnome;

    @Column(name = "minicial", length = 1)
    private String minicial;

    @Column(name = "unome", length = 15)
    private String unome;

    @Column(name = "datanasc")
    private LocalDate datanasc;

    @Column(name = "endereco", length = 255)
    private String endereco;

    @Column(name = "sexo", length = 1)
    private String sexo;

    @Column(name = "salario", precision = 10, scale = 2)
    private BigDecimal salario;

    @ManyToOne
    @JoinColumn(name = "cpf_supervisor")
    private Funcionario supervisor;

    @ManyToOne
    @JoinColumn(name = "dnr")
    private Departamento departamento;

    @OneToMany(mappedBy = "funcionario")
    private List<Dependente> dependentes;

    @OneToMany(mappedBy = "funcionario")
    private List<TrabalhaEm> trabalhaEm;

    public Funcionario() {}

    // Getters e Setters
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getPnome() {
        return pnome;
    }

    public void setPnome(String pnome) {
        this.pnome = pnome;
    }

    public String getMinicial() {
        return minicial;
    }

    public void setMinicial(String minicial) {
        this.minicial = minicial;
    }

    public String getUnome() {
        return unome;
    }

    public void setUnome(String unome) {
        this.unome = unome;
    }

    public LocalDate getDatanasc() {
        return datanasc;
    }

    public void setDatanasc(LocalDate datanasc) {
        this.datanasc = datanasc;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public Funcionario getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Funcionario supervisor) {
        this.supervisor = supervisor;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public List<Dependente> getDependentes() {
        return dependentes;
    }

    public void setDependentes(List<Dependente> dependentes) {
        this.dependentes = dependentes;
    }

    public List<TrabalhaEm> getTrabalhaEm() {
        return trabalhaEm;
    }

    public void setTrabalhaEm(List<TrabalhaEm> trabalhaEm) {
        this.trabalhaEm = trabalhaEm;
    }
}