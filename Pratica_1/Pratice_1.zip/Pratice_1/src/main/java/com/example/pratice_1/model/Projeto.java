package com.example.pratice_1.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "projeto")
public class Projeto {

    @Id
    @Column(name = "projnumero")
    private Integer projnumero;

    @Column(name = "projnome", length = 15)
    private String projnome;

    @Column(name = "projlocal", length = 15)
    private String projlocal;

    @ManyToOne
    @JoinColumn(name = "dnum")
    private Departamento departamento;

    @OneToMany(mappedBy = "projeto")
    private List<TrabalhaEm> trabalhaEm;

    public Projeto() {}

    // Getters e Setters
    public Integer getProjnumero() {
        return projnumero;
    }

    public void setProjnumero(Integer projnumero) {
        this.projnumero = projnumero;
    }

    public String getProjnome() {
        return projnome;
    }

    public void setProjnome(String projnome) {
        this.projnome = projnome;
    }

    public String getProjlocal() {
        return projlocal;
    }

    public void setProjlocal(String projlocal) {
        this.projlocal = projlocal;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public List<TrabalhaEm> getTrabalhaEm() {
        return trabalhaEm;
    }

    public void setTrabalhaEm(List<TrabalhaEm> trabalhaEm) {
        this.trabalhaEm = trabalhaEm;
    }
}